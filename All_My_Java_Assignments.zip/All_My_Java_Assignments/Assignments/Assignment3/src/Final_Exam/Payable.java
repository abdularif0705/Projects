package Final_Exam;

public interface Payable {
    double getPaymentAmount(); // calculate payment
}
