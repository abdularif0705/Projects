  public class TestMicrowave{
    public static void main(String[] args){
      Microwave microwave= new Microwave();
      microwave.startButton();
      microwave.increaseTime();
      microwave.switchLevel();
      microwave.increaseTime();
      microwave.increaseTime();
      microwave.increaseTime();
      microwave.switchLevel();
      microwave.stopButton();
      microwave.startButton();
      microwave.increaseTime();
      microwave.switchLevel();
      microwave.resetButton();
      microwave.increaseTime();
      microwave.increaseTime();
      microwave.startButton();
      microwave.increaseTime();
      microwave.switchLevel();
      microwave.increaseTime();
      microwave.switchLevel();
      microwave.stopButton();
    }
  }
