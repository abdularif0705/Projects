package Activity;

public class Apple extends Fruit implements Edible{

    public Apple(){}
    
    public String howToEat(){
        return "Apple: Bite into it raw, don't eat the centre unless human tree.";
    }
}