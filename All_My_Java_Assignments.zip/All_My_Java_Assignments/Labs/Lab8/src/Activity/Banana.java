package Activity;

public class Banana extends Fruit implements Edible{

    public Banana(){}
    
    public String howToEat(){
        return "Banana: Peel before eating, otherwise has problems. Sorry. But seriously could you imagine lol.";
    }
}