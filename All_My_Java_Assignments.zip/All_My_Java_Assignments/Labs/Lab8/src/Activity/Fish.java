package Activity;

public class Fish extends Animal implements Edible{

    public Fish(){}
    
    public String howToEat(){
        return "Fish: If you eat it raw reconsider your life choices. Shoutout Taka.";
    }
}