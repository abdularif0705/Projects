package Activity;

public abstract class Fruit implements Edible{

    public Fruit(){}
    
}