package Activity;

public interface Edible{
    public String howToEat();
}