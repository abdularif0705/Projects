package Activity;

public abstract class Animal implements Edible{
    
   public Animal(){}
}