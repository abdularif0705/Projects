package Activity2;

public interface Payable{
    public double getPaymentAmount();
}