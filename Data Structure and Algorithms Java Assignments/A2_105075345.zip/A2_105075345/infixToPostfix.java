package Assignment_2;
//Abdul Arif 105075345 06/19/2020
import java.util.Scanner;
import java.lang.Math;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

public class infixToPostfix {
    /**
     * @return true if operator
     */
    static boolean isOperator(String c1) {
        char c = c1.charAt(0);
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }

    /**
     * Checks if c2 has same or higher precedence than c1
     *@param s1 first operator
     *@param s2 second operator
     *@return true if c2 has same or higher precedence
     */
    static boolean checkPrecedence(String s1, String s2) {
        char c1 = s1.charAt(0);
        char c2 = s2.charAt(0);
        if((c2 == '+' || c2 == '-') && (c1 == '+' || c1 == '-'))
            return true;
        else if((c2 == '*' || c2 == '/') && (c1 == '+' || c1 == '-' || c1 == '*' || c1 == '/'))
            return true;
        else
            return (c2 == '^') && (c1 == '+' || c1 == '-' || c1 == '*' || c1 == '/');
    }

    /**
     * method that returns true or false based on whether the String has valid parenthesis or not
     * @param inputString the function
     * @return
     */
    public static boolean validParenthesis(String inputString) {
        // Declaring a stack
        StackADT<Character> stack = new StackADT<Character>(); // generified StackADT to type Character

        // Iterating over the entire string.
        for (char st: inputString.toCharArray()) {
            if("{}[]()".indexOf(st)>=0) { // If the input string contains an opening parenthesis, push in on to the stack.
                if (st == '(' || st == '{' || st == '[') {
                    stack.push(st);
                }
                else { // In the case of valid parenthesis, the stack cannot be empty if a closing parenthesis is encountered.
                    if(stack.isEmpty()) {
                        return false;
                    }
                    char top = stack.peek();
                    if(st == ')' && top == '(' || st == '}' && top == '{' || st == ']' && top == '[') { // If the input string contains a closing bracket, then pop the corresponding opening parenthesis if present.
                        stack.pop();
                    }
                }
            }
        }
        return stack.isEmpty(); // Checking the status of the stack to determine the validity of the string.
    }
    /**
     * Converts infix expression to postfix
     * @param strNum infix expression to be converted
     * @return postfix expression
     */
    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        // try-catch block
        try {
            Integer.parseInt(strNum);// statement that might cause exception
        }
        catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    static String[] convert(String[] infix) {
        //System.out.printf("%-8s%-10s%-15s\n", "Input", "Stack", "Postfix");
        String postfix = ""; //equivalent postfix is empty initially
        StackADT<String> stack = new StackADT<String>(); //stack to hold symbols
        stack.push("#"); //symbol to denote end of stack
        //System.out.printf("%-8s%-10s%-15s\n", "", format(stack.toString()), postfix);

        for(String i: infix) {
            String inputSymbol = i; //symbol to be processed
            if(isOperator(inputSymbol)) { //if operator repeatedly pops if stack top value has same or higher precedence
                while(checkPrecedence(inputSymbol, stack.peek()))
                    postfix += stack.pop()+" ";
                stack.push(inputSymbol);
            }
            else if(inputSymbol.equals("(")) {
                stack.push(inputSymbol); // push if left parenthesis
            }
            else if(inputSymbol.equals(")")) { //repeatedly pops if right parenthesis until left parenthesis is found
                while(!(stack.peek()).equals( "(" ))
                    postfix += stack.pop()+" ";
                stack.pop();
            }
            else
                postfix += inputSymbol+" ";
            //System.out.printf("%-8s%-10s%-15s\n", ""+inputSymbol,format(s.toString()),postfix);
        }
        while(stack.peek() != "#") { //pops all elements of stack left
            postfix += stack.pop()+" ";
            //System.out.printf("%-8s%-10s%-15s\n", "",format(s.toString()),postfix);
        }
        return postfix.split(" ");
    }

    static int evaluatePostfix(String[] postfix) { // Method to evaluate value of a postfix expression
        StackADT<Integer> stack= new StackADT<Integer>(); //create a stack

        for(String c: postfix) { // Scan all characters one by one
            if(isNumeric(c)) { // If the scanned character is an operand (number here), push it to the stack.
                stack.push(Integer.parseInt(c));
            }
            else { // If the scanned character is an operator, pop two elements from stack and apply the operator
                int val1 = stack.pop();
                int val2 = stack.pop();

                switch(c) {
                    case "+": //if + adds them
                        stack.push(val2+val1);
                        break;

                    case "-": //if - subtracts them
                        stack.push(val2- val1);
                        break;

                    case "/": //if / divides them
                        stack.push(val2/val1);
                        break;

                    case "*": //if * multiplies them
                        stack.push(val2*val1);
                        break;

                    case "^": //if ^ does to the power of function
                        stack.push((int)Math.pow(val2,val1));
                }
            }
        }
        return stack.pop();
    }

    /**
     * Formats the input stack string
     * @param s It is a stack converted to string
     * @return formatted input
     */
    static String format(String s) {
        s = s.replaceAll(", "," "); //removes all the commas in stack string
        s = s.substring(1, s.length()-1); //removes [] from stack string
        return s;
    }

    public static void main(String[] args) {
        String infix;
        //try-catch block
        try {
            File file = new File("equation.txt");
            Scanner sc = new Scanner(file);
            File answer = new File("answer.txt");
            answer.createNewFile();
            FileWriter fw = new FileWriter("answer.txt");
            while(sc.hasNextLine()) {
                infix = sc.nextLine(); // infix contains the first line (equation) from the equation.txt file
                if (validParenthesis(infix)) {
                    String[] infixArray = infix.split(" ");
                    //System.out.println(infixArray);
                    String[] postfix = convert(infixArray);

                    /*for (String i: postfix) {
                        System.out.print(i+" ");
                    }*/
                    int postValue = evaluatePostfix(postfix);
                    String equation = "";
                    for (String i: infixArray){
                        equation+=i;
                    }
                    //System.out.println("Postfix value = "+postValue);
                    fw.write( equation+" = "+ postValue+"\n" );
                }
                else {
                    //System.out.print(infix+" = Invalid");
                    fw.write( infix+" = Invalid.\n" );
                }
            }
            sc.close();
            fw.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        catch (IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}