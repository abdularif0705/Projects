package Challenges;
import java.util.Scanner;

public class Challenge3 {
    public static void main(String[] args) {
        int attempt = 1; // setting for the first attempt
        while (attempt <= 10) {
            StackADT<Integer> P = new StackADT<Integer>();
            StackADT<Integer> P1 = new StackADT<Integer>();
            StackADT<Integer> Q = new StackADT<Integer>();
            StackADT<Integer> Q1 = new StackADT<Integer>();
            int n = -1, m = -1, z = -1;
            int sum = 0; // Sum of all popped elements 'Joe' picks

            Scanner sc = new Scanner(System.in);
            System.out.println("Enter n (size of Stack P), m (size of Stack Q), z (number which you can't exceed)");
            while (n < 1 || n > 100) // constraint
                n = sc.nextInt();
            while (m < 1 || m > 100) // constraint
                m = sc.nextInt();
            while (z < 1 || z > 10000) // constraint
                z = sc.nextInt();

            for (int i = 0; i < n; i++) {
                System.out.println("Enter element to insert in Stack P");
                int p = sc.nextInt();
                if (p >= 0 && p <= 1000) { // constraint
                    P.push(p);
                    P1.push(p);
                }
                else {
                    System.out.println("Error please enter an integer between 0 and a 1000");
                    i--;
                }
            }
            for (int i = 0; i < m; i++) {
                System.out.println("Enter element to insert in Stack Q");
                int q = sc.nextInt();
                if (q >= 0 && q <= 1000) { // constraint
                    Q.push(q);
                    Q1.push(q);
                }
                else {
                    System.out.println("Error please enter an integer between 0 and a 1000");
                    i--;
                }
            }
            System.out.println("Input "+(attempt-1)+":\n");
            System.out.println("\tNumber of attempts: " + attempt);
            System.out.println("\tn, m, z: "+n+" "+m+" "+z);
            StackADT stack = P1; // points to nodes in duplicate Stack so the values won't disappear
            System.out.print("\tStack P: ");
            while(!stack.isEmpty())
                System.out.print(stack.pop()+", ");
            stack = Q1; // points to nodes in duplicate Stack so the values won't disappear
            System.out.print("\n\tStack Q: ");
            while(!stack.isEmpty())
                System.out.print(stack.pop()+", ");
            calculate_score(P, Q, z, attempt);
            attempt++; // for the next attempt
        }
    }

    /* To find score of each attempt */
    public static void calculate_score(StackADT<Integer> P, StackADT<Integer> Q, int z, int attempt) {
        int sum, score, choice;
        Scanner sc = new Scanner(System.in);

        // while loop for number of attempts
        sum = 0;
        score = 0;
        while (sum <= z) { // while loop to add total each time value selected either from stack P or Q
            System.out.println("\nEnter 1: Pop element from Stack P and add to sum\n"
                    + "Enter 2: Pop element from Stack Q and add to sum\n"
                    + "Enter 3: To peek at first element from Stack P\n"
                    + "Enter 4: To peek at first element from Stack Q\n");
            choice = sc.nextInt(); // read input choice

            switch (choice) {
                case 1: {
                    score++;
                    sum = sum + P.pop(); // adding popped value from top of Stack P to sum
                    // Printing present total and score each time
                    System.out.println("Sum: " + sum + "\nScore " + score);break;
                }
                case 2: {
                    score++;
                    sum = sum + Q.pop(); // // adding popped value from top of Stack Q to sum
                    // Printing present total and score each time
                    System.out.println("Sum: " + sum + "\nScore " + score);break;
                }
                case 3: {
                    System.out.println(P.peek());
                    break;
                }
                case 4: {
                    System.out.println(Q.peek());
                    break;
                }
                default: { // invalid choice
                    System.out.println("Wrong selection ");
                    break;
                }
            }

        }
        System.out.println("Output "+(attempt-1)+":");
        System.out.println("\tScore : " + score);
        System.out.println("----------------------------------");
        System.out.println("Abdul Arif\n" +
                "Student ID: 105075345");
    }
}

