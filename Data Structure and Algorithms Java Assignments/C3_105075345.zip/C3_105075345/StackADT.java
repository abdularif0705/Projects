package Challenges;
//Abdul Arif 105075345 06/19/2020
/**
 * Generic version of the StackADT class.
 * @param <E> the type of the value being boxed
 */
public class StackADT<E> { // Takes in Generic element type
    // E stands for "Element "
    public class Node {
        E data;
        Node next;

        public Node(E data, Node next) { // parameterized constructor
            //setting local scoped variables to the variables passed through parameter
            this.data = data;
            this.next = next;
        }
    }

    Node head; // private object named head declared for type Node

    public void push(E value) { //method to replicate in-built library function Stack.push method
        head = new Node(value, head); //new node named Node created and is made the new head
    }

    /**
     * StackADT pop method
     * @return data
     */
    public E pop() {
        E data = head.data; // value of the current head is assigned to variable data
        head = head.next; // assign the next node as the head
        return data; //data of the popped (deleted) node is returned
    }

    /**
     * returning the top value of the Stack
     * @return head.data
     */
    public E peek() {
        return head.data;
    }

    public boolean isEmpty() { //method that returns true if head is equal to null, else false is returned.
        return head == null;
    }
    /*public void display(){ //DOESNT WORK FIX IT AFTER*******************
        while(head!=null){
            E data = head.data; // value of the current head is assigned to variable data
            head = head.next; // assign the next node as the head
            //data of the popped (deleted) node is returned
            System.out.print(data + ", ");
        }
    }
    */

/*    public int getSize() {
        int count = 0;
        Node temp = head;
        while (temp != null) {
            ++count;
            temp = temp.next;
        }
        return count;
    }*/
}