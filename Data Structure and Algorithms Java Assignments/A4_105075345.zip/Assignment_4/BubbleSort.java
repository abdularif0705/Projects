package Assignment_4;
//Abdul Arif 105075345 07/24/2020
//Q2 c) in place bubble sort
// Java program for implementation of Bubble Sort
class BubbleSort {
    void bubbleSort(int arr[]) {
        for (int i=0; i<arr.length-1; i++)
            for (int j=0; j<arr.length-i-1; j++)
                if (arr[j] > arr[j+1]) {
                    // swap arr[j+1] and arr[i]
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
    }

    /* Prints the array */
    void printArray(int arr[]) {
        for (int i=0; i<arr.length; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

    // Driver method to test above
    public static void main(String args[]) {
        BubbleSort ob = new BubbleSort();

        int[] arr = {14, 25, 12, 11, 13, 5, 36, 7}; //a
        ob.bubbleSort(arr);
        System.out.println("Bubble Sorted array");
        ob.printArray(arr);

        arr = new int[]{38, 17, 3, 82, 9, 15, 43};//b
        ob.bubbleSort(arr);
        System.out.println("Bubble Sorted array");
        ob.printArray(arr);

        arr = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};//c
        ob.bubbleSort(arr);
        System.out.println("Bubble Sorted array");
        ob.printArray(arr);

        arr = new int[]{10, 9, 8, 7, 6, 5, 4, 3, 2, 1};//d
        ob.bubbleSort(arr);
        System.out.println("Bubble Sorted array");
        ob.printArray(arr);
    }
}
