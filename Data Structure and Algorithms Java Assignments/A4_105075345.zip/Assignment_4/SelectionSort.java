package Assignment_4;
//Abdul Arif 105075345 07/24/2020
//Q2 a) in place selection sort

// class implementation of Selection Sort
public class SelectionSort {
    public void selectionSort(int arr[]) {
        int n = arr.length;

        // One by one move boundary of unsorted subarray
        for (int i = 0; i < n-1; i++) {
            // Find the minimum element in unsorted array
            int min_idx = i;
            for (int j = i+1; j < n; j++)
                if (arr[j] < arr[min_idx])
                    min_idx = j;

            // Swap the found minimum element with the first element
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }
    }

    // Prints the array
    void printArray(int arr[]) {
        for (int i=0; i<arr.length; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

    // Driver code to test above
    public static void main(String args[]) {
        SelectionSort ob = new SelectionSort();

        int[] arr = {14, 25, 12, 11, 13, 5, 36, 7}; //a
        ob.selectionSort(arr);
        System.out.println("Selection Sorted array");
        ob.printArray(arr);

        arr = new int[]{38, 17, 3, 82, 9, 15, 43};//b
        ob.selectionSort(arr);
        System.out.println("Selection Sorted array");
        ob.printArray(arr);

        arr = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};//c
        ob.selectionSort(arr);
        System.out.println("Selection Sorted array");
        ob.printArray(arr);

        arr = new int[]{10, 9, 8, 7, 6, 5, 4, 3, 2, 1};//d
        ob.selectionSort(arr);
        System.out.println("Selection Sorted array");
        ob.printArray(arr);
    }
}