package Assignment_4;
//Abdul Arif 105075345 07/24/2020
public class MergeSort {
    // Merges two subarrays of arr[].
    // First subarray is arr[left..mid]
    // Second subarray is arr[mid+1eft..right]
    void mergeSort(int arr[], int left, int mid, int right) {
        // Find sizes of two subarrays to be merged
        int n1 = mid - left + 1;
        int n2 = right - mid;

        /* Create temp arrays */
        int L[] = new int[n1];
        int R[] = new int[n2];

        /*Copy data to temp arrays*/
        for (int i = 0; i < n1; ++i)
            L[i] = arr[left + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[mid + 1 + j];

        /* Merge the temp arrays */

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarry array
        int k = left;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            }
            else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        /* Copy remaining elements of L[] if any */
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        /* Copy remaining elements of R[] if any */
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    // method that sorts array using merge()
    void sort(int arr[], int left, int right) {
        if (left < right) { //if first index is less than last index (NOT values)
            // Find the middle point
            int mid = (left + right) / 2;

            // Sort first and second halves
            sort(arr, left, mid);
            sort(arr, mid+1, right);

            // Merge the sorted halves
            mergeSort(arr, left, mid, right);
        }
    }

    //Function to print array of size
    static void printArray(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

    public static void main(String[] args) {
        MergeSort ob = new MergeSort();

        int[] arr = {14, 25, 12, 11, 13, 5, 36, 7}; //a
        System.out.println("Merge Sorted array");
        System.out.println("Original Sequence: ");
        MergeSort.printArray(arr);

        ob.sort(arr, 0, arr.length - 1);

        System.out.println("Sorted Sequence");
        MergeSort.printArray(arr);

        arr = new int[]{38, 17, 3, 82, 9, 15, 43};//b
        System.out.println("Merge Sorted array");
        System.out.println("Original Sequence: ");
        MergeSort.printArray(arr);

        ob.sort(arr, 0, arr.length - 1);

        System.out.println("Sorted Sequence");
        MergeSort.printArray(arr);

        arr = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};//c
        System.out.println("Merge Sorted array");
        System.out.println("Original Sequence: ");
        MergeSort.printArray(arr);

        ob.sort(arr, 0, arr.length - 1);

        System.out.println("Sorted Sequence");
        MergeSort.printArray(arr);

        arr = new int[]{10, 9, 8, 7, 6, 5, 4, 3, 2, 1};//d
        System.out.println("Merge Sorted array");
        System.out.println("Original Sequence: ");
        MergeSort.printArray(arr);

        ob.sort(arr, 0, arr.length - 1);

        System.out.println("Sorted Sequence");
        MergeSort.printArray(arr);
    }
}