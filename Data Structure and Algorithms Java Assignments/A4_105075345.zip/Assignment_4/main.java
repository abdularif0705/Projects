package Assignment_4;
//Abdul Arif 105075345 07/24/2020
import java.util.Scanner;
public class main {
    //Selection sort method implementation
    public static void selectionSort(int[] arr){
        PriorityQueueADT ss = new PriorityQueueADT();
        for(int i=0;i<arr.length;i++)//sift thru entire array
            ss.enqueueUnsorted(arr[i]);//send the number directly to be set to queue
        while(!ss.isEmpty()){
            System.out.printf("%d ",ss.dequeueSorted()); //array gets sorted and is printed
        }
    }
    //Insertion Sort function implementation
    public static void insertionSort(int[] arr){
        PriorityQueueADT pq = new PriorityQueueADT();
        for(int i=0;i<arr.length;i++)
            pq.enqueueSorted(arr[i]);
        while(!pq.isEmpty()){
            System.out.printf("%d ",pq.dequeueUnsorted());
        }
    }
    //main method
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter no. of test cases: ");
        int t = sc.nextInt();
        while(t>0) {
            System.out.print("Enter no. of elements: ");
            int n = sc.nextInt();
            int[] arr = new int[n];
            System.out.print("Enter elements: ");
            for (int i = 0; i < n; i++)
                arr[i] = sc.nextInt();
            System.out.print("Selection sort: ");
            selectionSort(arr);
            System.out.print("\nInsertion sort: ");
            insertionSort(arr);
            System.out.print("\n");
            t--;
        }
        int []arr = {14, 25, 12, 11, 13, 5, 36, 7}; //a
        System.out.print("Selection sort: ");
        selectionSort(arr);
        System.out.print("\nInsertion sort: ");
        insertionSort(arr);
        System.out.print("\n");
        arr = new int[]{38, 17, 3, 82, 9, 15, 43};//b
        System.out.print("Selection sort: ");
        selectionSort(arr);
        System.out.print("\nInsertion sort: ");
        insertionSort(arr);
        System.out.print("\n");
        arr = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};//c
        System.out.print("Selection sort: ");
        selectionSort(arr);
        System.out.print("\nInsertion sort: ");
        insertionSort(arr);
        System.out.print("\n");
        arr = new int[]{10, 9, 8, 7, 6, 5, 4, 3, 2, 1};//d
        System.out.print("Selection sort: ");
        selectionSort(arr);
        System.out.print("\nInsertion sort: ");
        insertionSort(arr);
        System.out.print("\n");
    }
}
