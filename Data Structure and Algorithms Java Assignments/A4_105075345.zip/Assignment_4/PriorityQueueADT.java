package Assignment_4;
//Abdul Arif 105075345 07/24/2020
/*
There are two ways in which we can use the priority queue.
    1. Selection Sort: We can insert the element in the end with time complexity O(1)
    and when we remove, we find the smallest element and remove it
    with time complexity O(n),

    2. Insertion Sort: We can insert the element in sorted order with time complexity O(n)
    that means when we insert elements, we arrange them in order, and when
    we remove element, we do it from the end because our queue is already
    sorted with time complexity of O(1).
*/
public class PriorityQueueADT {
    private int size = 100;
    private int[] elements;
    private int index;

    public PriorityQueueADT(){ //Constructor
        this.index = -1;
        this.elements = new int[size];
    }
    //insert directly without sorting for selection sort
    public void enqueueUnsorted(int num){
        this.elements[++this.index] = num; //insert number and increment index
    }

    //insert with sorting for insertion sort
    public void enqueueSorted(int num){
        if(this.index==-1)
            this.elements[++this.index] = num; // initial value
        else if (!isEmpty()){
            int i = this.index;
            for (; i >= 0; i--) {
                if (num > this.elements[i])
                    this.elements[i + 1] = this.elements[i];
                else
                    break;
            }
            this.elements[i + 1] = num;
            ++this.index;
        }
    }
    /*public boolean isEmpty(){
        if(this.index==-1)
            return true;
        else return false;
    }*/
    // method to return true is queue is empty else false
    public boolean isEmpty() {
        return(index == -1);
    }// better way to do it

    public int getSize(){ return this.size; }

    //dequeue with sorting for insertion sort
    public int dequeueSorted(){
        if(this.isEmpty())
            return -1;
        else{
            int min = 999999, min_idx=0; //set min to big number so min will be set to first number
            for (int i=0;i<=this.index;i++){
                if(min>this.elements[i]) {
                    min = this.elements[i];
                    min_idx = i;
                }
            }
            int elem = this.elements[min_idx]; // set elem to min value
            for(int i=min_idx+1;i<=this.index;i++){
                this.elements[i-1] = this.elements[i];
            }
            this.index-=1;
            return elem;
        }
    }
    //dequeue with out sorting for selection sort
    public int dequeueUnsorted(){
        if(!isEmpty()){
            this.index--;
            return this.elements[this.index+1];
        }
        else return -1;
    }
}