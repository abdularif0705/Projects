package Challenges;

public class Challenge2 {
    public static void main(String[] args) {
        LinkedList Test1 = new LinkedList();
        Test1.insertData("1");
        System.out.println("Output: " + Test1.detectAndRemoveLoop());

        LinkedList Test2 = new LinkedList();
        Test2.insertData("D");
        Test2.insertData("A");
        Test2.insertData("T");
        Test2.loop1(); // Here 3rd element linked to 2nd element
        System.out.println("Output: " + Test2.detectAndRemoveLoop());
        Test2.displayData();

        LinkedList Test3 = new LinkedList();
        Test3.insertData("C");
        Test3.insertData("O");
        Test3.insertData("M");
        Test3.insertData("P");
        Test3.insertData("25");
        Test3.insertData("4");
        Test3.insertData("0");
        Test3.loop2(); // Here last element linked to 2nd last element
        System.out.println("Output: " + Test3.detectAndRemoveLoop());
        Test3.displayData();

        LinkedList Test4 = new LinkedList();
        Test4.insertData("B");
        Test4.insertData("I");
        Test4.insertData("N");
        Test4.insertData("A");
        Test4.insertData("R");
        Test4.insertData("Y");
        Test4.insertData("T");
        Test4.insertData("R");
        Test4.insertData("E");
        Test4.insertData("E");
        System.out.println("Output: " + Test4.detectAndRemoveLoop());
        System.out.println("Abdul Arif " +
                "\nStudent ID: 105075345");
    }
}
