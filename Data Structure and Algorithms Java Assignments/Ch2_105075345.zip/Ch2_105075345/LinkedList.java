package Challenges;

public class LinkedList {
    Node head; // head of the list - first element
    public class Node {
        Node next;  //pointer to the next node
        String data;   // value of the data

        //Constructure
        public Node(String data) {
            this.data = data;
        }
    }

    //Insert at the front
    public void insertFirst(String data)
    {
        Node newHead=new Node(data);  // crate the new node
        newHead.next=head;       // assign the existing head at next
        head = newHead;         //  assign the new node at head
    }

    public void insertAt(int position,String data)
    {
        if (head==null) return;
        Node newNode=new Node(data);  //create a new node
        Node previous=head;      // temporary node to point head
        int count=1;
        // find the position to insert data
        while(count<position-1)
        {
            previous=previous.next;
            count++;
        }
        Node current=previous.next;     // temporary node
        newNode.next=current;
        previous.next=newNode;
    }

    // Insert at the rear
    public void insertData(String data){
        //check whether you are inserting to the head or node
        if(head==null) {
            head = new Node(data);
            return;
        }
        Node current = head;        // Initialize current
        while(current.next!=null)   //check until last node
        {
            current=current.next;   // move pointer one by one
        }
        current.next=new Node(data); // when the pointer reaches the null pointer, insert the data.
    }

    // delete an element at first
    public void deleteFirst()
    {
        Node current= head;
        head=head.next;
        current.next=null;
    }

    //delete an element at rear
    public void deleteData()
    {
        Node current = head;    // Initialize current
        Node previous=null;

        while(current.next!=null)
        {
            previous=current;
            current=current.next;
        }
        previous.next=null;

    }

    //delete an element at the middle
    public void deleteAt(int position)
    {
        if (head==null) return;
        Node previous=head;      // temporary node to point head
        int count=1;
        // find the position to delete data
        while(count<position-1)
        {
            previous=previous.next;
            count++;
        }
        Node current=previous.next;     // temporary node
        previous.next=current.next;
        current.next=null;
    }

    public boolean isContain(String data)
    {
        Node current = head;
        while (current!=null)
        {
            if(current.data==data)
                return true;
            current=current.next;
        }
        return false;
    }

    // print element in the linkedlist
    public void displayData()
    {
        Node current = head;
        while(current!=null)
        {
            System.out.print(current.data + "->");
            current=current.next;
        }
        System.out.println();
    }
    // Function that detects loop in the list
    String detectAndRemoveLoop() {
        Node tortoise = head;
        Node hare = head;
        while (tortoise != null && hare != null && hare.next != null) {
            // Move tortoise one step ahead and hare 2 steps ahead
            tortoise = tortoise.next;
            hare = hare.next.next;

            // If tortoise and hare meet at same point then loop is present
            if (tortoise == hare) {
                removeLoop(tortoise, head);
                return "Yes";
            }
        }
        return "No";
    }

    // Function to remove loop
    void removeLoop(Node loop, Node current) {
        Node tortoise = null;
        Node hare = null;

        // Set a pointer to the head of the Linked List and move it one by one to find the first node which is part of the Linked List
        tortoise = current;
        while (true) {

            // Setting hare as a pointer from loop_node and check if it ever reaches tortoise
            hare = loop;
            // Search for loop using slow and fast pointers
            while (hare.next != loop && hare.next != tortoise) {
                hare = hare.next;
            }

            // If hare reached tortoise then there is a loop. So break the loop
            if (hare.next == tortoise)
                break;

            // If hare did't reach tortoise then try the next node after tortoise
            else
                tortoise = tortoise.next;
        }

        // since hare->next is the looping point
        hare.next = null;
    }
    void loop1(){//Creating loop for test2
        head.next.next.next = head.next;
    }

    void loop2(){ //Creating loop for test3
        head.next.next.next.next.next.next.next =head.next.next.next.next.next;
    }
}