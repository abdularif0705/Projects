package Assignment_3;
//Abdul Arif 105075345 07/01/2020
/**
 * Generic version of the PriorityQueueADTL class.
 * @param <T> the type of the value being boxed
 */
// using array [task 2]
public class PriorityQueueADT<T> { // Takes in Generic element type
    // T stands for "Type "

    private T[]list; // Generic array storing the elements of the queue
    private int[] plist;
    private int size;
    private int rearIndex;

    // default constructor
    public PriorityQueueADT() {
        this.size=100;
        this.rearIndex=0;
        this.list= (T[])new Object[this.size]; // Create a new Array that takes in Generic Type T
        this.plist=new int[this.size]; // PriorityList Array
    }

    // method to insert an element to the queue appropriate
    //position in the queue based on the associated priority. If the priority
    //parameter is missing, assign to the element 10 as default priority, which
    //is the lowest priority.
    public void enqueue(T data, int priority) {
        int i=0;
        for(i=0; i<this.rearIndex; i++) {
            if(this.plist[i]>priority) { // finds the position where to insert the new element
                break;
            }
        }
        //ASK ABDULLAH********
        for(int j=this.rearIndex; j>i; j--){
            this.list[j] = this.list[j-1];// shift the elements to right by 1 index
            this.plist[j] = this.plist[j-1];
        }

        rearIndex++;
        this.list[i] = data; // set data in correct priority position
        this.plist[i] = priority;
    }

    // method that removes and returns the entry with highest priority from the
    //queue, or null if the priority queue is empty. If two elements have the
    //same priority, they are considered according to their order in the queue.
    public void dequeue() {
        if(isEmpty()) // empty queue
            throw new IllegalStateException("Queue is empty");
        else if(this.rearIndex>0){
            // shift the elements to left by 1 index
            for(int i=0; i<this.rearIndex; i++){
                this.list[i] = this.list[i+1];
                this.plist[i] = this.plist[i+1];
            }
            this.rearIndex--; // decrement the index of last element
        }
    }

    //method returns the element to be considered from the queue without
    //removing it.
    public T peek(){
        if(isEmpty()) // empty queue
            throw new IllegalStateException("Queue is empty");
        else if(this.rearIndex>0){ // return the front element of the queue
            return this.list[this.rearIndex-1];
        }
        return this.list[0];
    }

    //returns the total number of elements in the queue.
    public int getSize(){ return this.rearIndex; }

    // returns true if the queue is empty.
    public boolean isEmpty(){ return this.rearIndex==0; }

    // returns true if the queue is full.
    public boolean isFull(){ return this.rearIndex==this.size; }

    // prints all the elements in the queue with their priority.
    public void display() {
        if (isEmpty()) {
            System.out.println("Empty queue");
        }
        else {
            System.out.println("Priority Queue using an Array");
            for (int i = 0; i < this.rearIndex; i++) {
                System.out.println("Element " + (i + 1) + " : " + this.list[i] + " [" + this.plist[i] + "]");
            }
        }
    }
}