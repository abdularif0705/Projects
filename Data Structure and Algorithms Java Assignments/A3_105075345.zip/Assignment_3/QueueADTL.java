package Assignment_3;
//Abdul Arif 105075345 07/01/2020
/**
 * Generic version of the QueueADTL class.
 * @param <T> the type of the value being boxed
 */
// using LinkedList [task 1]
public class QueueADTL<T>{// Takes in Generic element type
    // T stands for "Type "
    // Node class of the Queue
    public class Node {
        private T data;
        private Node next;

        public Node(T data) {
            this.data = data;
            next = null;
        }

        // Getters and Setters

        public T getData() { return data; }

        public void setData(T data) { this.data = data; }

        public Node getNext() { return next; }

        public void setNext(Node next) { this.next = next; }
    }

    private Node front; // front node of the queue
    private Node rear; // end node of the queue
    private int size; // number of elements in the queue

    // constructor to create an empty queue
    public QueueADTL() {
        front = null;
        rear = null;
        size = 0;
    }

    // method to insert an element at the end of queue
    public void enqueue(T data) {
        Node node = new Node(data); // create a new node
        if(isEmpty()) { // empty queue, make front and rear point to node
            front = node;
        }
        else {
            // non-empty queue, insert node at the end
            rear.setNext(node);
        }
        rear = node;
        size++;
    }

    // method to remove and return the front element of the queue
    public T dequeue() {
        if(!isEmpty()) { // non-empty queue
            T data = front.getData(); // get the data at the front
            front = front.getNext();  // set front to node next to front

            if(front == null) // after removal if queue is empty, set rear to null
                rear = null;
            this.size--; // decrement the size

            return data;
        }
        else
            throw new IllegalStateException("Queue is empty");
    }

    // method to return the front element of the queue without removing it
    public T peek(){
        if(!isEmpty()) // non-empty queue
            return front.getData();
        else // empty queue
            throw new IllegalStateException("Queue is empty");
    }

    // method that returns true if queue is empty else false
    public boolean isEmpty() {
        return(front == null);
    }

    // since Queue is represented using Linked list, it doesn't have any maximum capacity
    public boolean isFull(){
        return false;
    }

    // method to return the number of elements in the queue
    public int getSize() {
        return size;
    }

    // method to print all the elements of the queue
    public void display() {
        if(isEmpty())
            System.out.println("Empty queue");
        else {
            System.out.println("Queue using LinkedList:");
            Node current = front; // set current to front of queue
            System.out.print("{");
            while(current != rear) { // loop til we reach the end of queue
                // display the current element of the queue
                System.out.print(current.getData()+", ");
                current = current.getNext(); // go to next node
            }
            // display the rear node of the queue
            System.out.println(rear.getData() +"}");
        }
    }
}