package Assignment_3;

// main function for task1 and task2 both

public class Main {
    public static void main(String [] args){
        QueueADT queue=new QueueADT();
        QueueADTL queuel=new QueueADTL();
        PriorityQueueADT pqueue=new PriorityQueueADT();
        PriorityQueueADTL pqueuel=new PriorityQueueADTL();

        System.out.println();
        System.out.println();
        //QueueADT Array
        //Task 1: Test 1
        System.out.println("Task 1: Test 1");
        queue.enqueue("Java");
        queue.enqueue("Python");
        queue.enqueue("XML");
        queue.enqueue("CSS");
        queue.enqueue("LISP");

        queue.display();
        queue.dequeue();
        queue.display();
        queue.enqueue("JSON");
        queue.display();

        System.out.println();
        System.out.println();
        //QueueADTL LinkedList
        // Task 1: Test 2
        System.out.println("Task 1: Test 2");
        queuel.enqueue(3);
        queuel.enqueue(2.26);
        queuel.enqueue("Luffy");
        queuel.enqueue(-0.35);
        queuel.enqueue('F');

        queuel.display();
        System.out.println("Size is "+queuel.getSize()+"\n");

        System.out.println("\ndequeue 5 elements");

        queuel.dequeue();
        queuel.dequeue();
        queuel.peek();
        queuel.dequeue();
        queuel.display();
        queuel.dequeue();
        queuel.dequeue();

        queuel.display();
        System.out.println("Size is "+queuel.getSize()+"\n");

        System.out.println();
        System.out.println();
        //PriorityQueueADTL Array
        //Task 2: Test 1
        System.out.println("Task 2: Test 1");
        pqueue.enqueue("Java",2);
        pqueue.enqueue("Python",1);
        pqueue.enqueue("XML",4);
        pqueue.enqueue("HTML",2);
        pqueue.enqueue("CSS",3);
        pqueue.display();
        pqueue.dequeue();
        pqueue.display();
        pqueue.enqueue("JSON", 3);
        pqueue.display();
        System.out.println("Size is "+pqueue.getSize()+"\n");

        System.out.println();
        System.out.println();
        //PriorityQueueADTL LinkedList
        // Task 2: Test 2
        System.out.println("Task 2: Test 2");
        pqueuel.enqueue("DaBaby",2);
        pqueuel.enqueue(200*546456,4);
        pqueuel.enqueue("Roddy Rich",7);
        pqueuel.enqueue(4*243/8+10,3);
        pqueuel.enqueue(100*2.8,4);
        pqueuel.enqueue("GANG GANG GANG NIGGA "+"NLE Choppa BITCH!",1);
        pqueuel.enqueue(-0005.77,7);
        pqueuel.enqueue(-99.08878,6);
        pqueuel.enqueue("Tekashi"+69 + " is a bitch",2);

        pqueuel.display();
        System.out.println("Size is "+pqueuel.getSize()+"\n");

        System.out.println("\ndequeue 7 elements");

        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.peek();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.display();
        System.out.println("Size is "+pqueuel.getSize()+"\n");
        pqueuel.dequeue();
        pqueuel.dequeue();

        if (pqueuel.isEmpty())
            System.out.println("Yes it's empty");
        else
            System.out.println("Nope it's not empty");


        System.out.println();
        System.out.println();
        //PriorityQueueADTL LinkedList
        // Task 2: Test 3
        System.out.println("Task 2: Test 3");
        pqueuel.enqueue("DaBaby",2);
        pqueuel.enqueue(200*546456,4);
        pqueuel.enqueue("Roddy Rich",7);
        pqueuel.enqueue(4*243/8+10,3);
        pqueuel.enqueue(100*2.8,4);
        pqueuel.enqueue("GANG GANG GANG NIGGA "+"NLE Choppa BITCH!",1);
        pqueuel.enqueue(-0005.77,7);
        pqueuel.enqueue(-99.08878,6);
        pqueuel.enqueue("Tekashi"+69 + " is a hero tho for ratting out the rapists and killers.",2);
        pqueuel.peek();

        pqueuel.display();
        System.out.println("Size is "+pqueuel.getSize()+"\n");

        System.out.println("\ndequeue 7 elements");

        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.peek();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.dequeue();
        pqueuel.display();
        System.out.println("Size is "+pqueuel.getSize()+"\n");
    }
}