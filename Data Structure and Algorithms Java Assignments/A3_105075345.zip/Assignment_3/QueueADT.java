package Assignment_3;
//Abdul Arif 105075345 07/01/2020
/**
 * Generic version of the QueueADTL class.
 * @param <T> the type of the value being boxed
 */
// using array [task 1]
public class QueueADT<T> {// Takes in Generic element type
    // T stands for "Type "

    private int size = 100; // default maximum number of elements in the Queue
    private T[] elements; // Generic array storing the elements of the queue
    private int rearIndex = -1; // index of the last element of the queue

    // default constructor
    public QueueADT() {
        elements = (T[])new Object[size];
        this.rearIndex = -1;
    }

    // parameterized constructor
    public QueueADT(int size) {
        elements = (T[])new Object[size];
        rearIndex = -1;
    }

    // method to insert an element at the end of queue
    public void enqueue(T data) {
        if(!isFull()){ // queue not full
            this.rearIndex++; // increment the index of last element
            elements[this.rearIndex] = data; // insert the data
        }
    }
    // method to remove and return the front element of the queue
    public void dequeue() {
        if(isEmpty()) // empty queue
            throw new IllegalStateException("Queue is empty");

        // shift the elements to left by 1 index
        for(int i=0; i<this.rearIndex; i++)
            elements[i] = elements[i+1];
        this.rearIndex--; // decrement the index of last element
    }

    // method to return the front element of the queue without removing it
    public T peek() {
        if(isEmpty()) // empty queue
            throw new IllegalStateException("Queue is empty");
        else // return the front element of the queue
            return elements[0];
    }

    // method to return true is queue is empty else false
    public boolean isEmpty() {
        return(rearIndex == -1);
    }

    // method to return true is queue is full else false
    public boolean isFull() {
        return(getSize() == elements.length);
    }

    // method to return the number of elements stored in the queue
    public int getSize() {
        return rearIndex+1;
    }

    // method to print all the elements in the queue
    public void display() {
        if(isEmpty()) {
            System.out.println("Empty queue");
        }
        else {
            System.out.println("Queue: using an Array");
            System.out.print("[");
            for(int i=0; i<rearIndex; i++) {
                System.out.print(elements[i]+", ");
            }
            System.out.println(elements[rearIndex] + "]");
        }
    }
}