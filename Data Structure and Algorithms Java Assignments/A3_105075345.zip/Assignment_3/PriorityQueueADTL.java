package Assignment_3;
//Abdul Arif 105075345 07/01/2020
/**
 * Generic version of the PriorityQueueADTL class.
 * @param <T> the type of the value being boxed
 */
//using LinkedList [task 2]
public class PriorityQueueADTL<T> {// Takes in Generic element type
    // T stands for "Type "
    // Node class of the PriorityQueue
    public class NodeP {
        private T data;
        private int priority;
        private NodeP next;

        public NodeP(T data, int priority) {
            this.setData(data);
            this.setPriority(priority);
            this.setNext(null);
        }

        // Getters and Setters

        public NodeP getNext() {
            return next;
        }

        public void setNext(NodeP next) {
            this.next = next;
        }

        public int getPriority() {
            return priority;
        }

        public void setPriority(int priority) {
            this.priority = priority;
        }

        public T getData() {
            return data;
        }

        public void setData(T data) {
            this.data = data;
        }
    }

    private NodeP head; // create head node

    // constructor to create an empty queue
    public PriorityQueueADTL(){
        this.head = null;
    }

    // method to insert an element to the queue appropriate
    //position in the queue based on the associated priority. If the priority
    //parameter is missing, assign to the element 10 as default priority, which
    //is the lowest priority.
    public void enqueue(T data, int priority){
        NodeP node=new NodeP(data, priority); // create a new node

        if(head == null) { // empty queue, set next to null as that'll be the last element and head will be the first node
            node.setNext(null);
            head = node;
        }
        else {
            // non-empty queue, insert node at the start
            if(head.getPriority()>priority) {
                node.setNext(head);
                head = node;
            }
            else {
                NodeP current = this.head; // current node will point to head
                NodeP previous = null;

                boolean bool = false;

                while(current != null){
                    if(current.getPriority() > priority){ // finds the position where to insert the new element
                        node.setNext(current); // set data in correct priority position
                        previous.setNext(node);
                        bool = true;
                        break;
                    }
                    previous = current; // sifting through the LinkedList
                    current = current.getNext();
                }

                if(bool == false) {
                    previous.setNext(node); //sets at end of Linked List
                }
            }
        }
    }

    // method that removes and returns the entry with highest priority from the
    //queue, or null if the priority queue is empty. If two elements have the
    //same priority, they are considered according to their order in the queue.
    public T dequeue() {
        NodeP current=this.head;
        if(current == null) {
            return null;
        }
        else { // non-empty queue
            T data = this.head.getData();
            this.head = this.head.getNext();
            return data;
        }
    }

    //method returns the element to be considered from the queue without
    //removing it.
    public T peek() {
        NodeP current = this.head;
        if(current == null) { // empty queue
            return null;
        }
        else { // non-empty queue
            return this.head.getData(); // return head value
        }
    }
    //returns the total number of elements in the queue.
    public int getSize() {
        int size = 0;
        NodeP current = this.head;
        while(current != null) {
            size++;
            current = current.getNext();
        }
        return size;
    }

    // returns true if the queue is empty.
    public boolean isEmpty(){
        return this.head == null;
    }

    // since PriorityQueue is represented using Linked list, it doesn't have any maximum capacity
    public boolean isFull(){
        return false;
    }

    // prints all the elements in the queue with their priority.
    public void display() {
        System.out.println("Priority Queue using LinkedList");
        NodeP current = this.head; // set current to head of queue
        int i=0;
        while(current != null) { // loop til we reach the end of queue
            // display the current element of the queue
            System.out.println("Element "+(i+1)+" : "+current.getData()+" ["+current.getPriority()+"]");
            i++;
            current = current.getNext(); // go to next node
        }
    }
}